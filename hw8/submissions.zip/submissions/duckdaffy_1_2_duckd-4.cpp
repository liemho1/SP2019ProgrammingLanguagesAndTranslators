#include <iostream>
#include <stdlib.h>
using namespace std;


int main(int argc, char** argv)
{
  int n = atoi(argv[1]);
  int r = atoi(argv[2]);
  cout << n * r << endl;
  return 0;
} 

